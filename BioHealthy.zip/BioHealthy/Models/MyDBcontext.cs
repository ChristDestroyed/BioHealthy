﻿namespace BioHealthy.Models
{
    internal class MyDBcontext
    {
        public object Empleados { get; internal set; }
    }
}