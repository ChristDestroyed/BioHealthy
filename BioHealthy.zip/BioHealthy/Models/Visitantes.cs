﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BioHealthy.ClientApp.Models
{
  public class Visitantes
  {
public int id { get; set; }
        public int documento { get; set; }
        public string nombre { get; set; }
        public string apellidos { get; set; }
        public string cargo { get; set; }
        public string ciudad{get; set;}


  }
}
