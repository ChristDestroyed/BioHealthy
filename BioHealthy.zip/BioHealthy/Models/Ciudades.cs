using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BioHealthy.ClientApp.Models
{
  public class Ciudad
  {
        public int  IdCiudad { get; set; }
        public int  Ciudad { get; set; }
        
    }
}
