using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BioHealthy.ClientApp.Models
{
  public class Huellas
    {
        public int IdHuella { get; set; }
        public int Huella { get; set; }
        public int NombreHuella { get; set; }
    }
   
}
