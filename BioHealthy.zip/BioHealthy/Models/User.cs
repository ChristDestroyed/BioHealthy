namespace BioHealthy.ClientApp.Models
{
    public class User
    {

        public int id { get; set; }
        public int email { get; set; }
        public string password { get; set; }




    }
}
